from types import SimpleNamespace

from src.citations import citation_source_match, extract_cited_sources, make_source_excerpts
from src.documents import chunk_text, load_documents, make_records
from src.policy import classify_policy_intent, policy_filter


def test_chunk_text_covers_text():
    text = "word " * 1000
    chunks = chunk_text(text, chunk_size=300, overlap=50)
    assert len(chunks) > 1
    assert all(chunks)
    assert " ".join(chunks).replace("  ", " ").strip()


def test_all_knowledge_docs_load():
    items = load_documents()
    names = {item['source'] for item in items}
    assert '03_current_customer_policy.md' in names
    assert '04_archived_customer_policy.md' in names
    assert len(items) >= 5


def test_metadata_is_preserved():
    records = make_records(load_documents())
    current = [r for r in records if r['metadata']['source']=='03_current_customer_policy.md']
    assert current
    assert current[0]['metadata']['policy_version']=='NHT-CP-3.1'
    assert current[0]['metadata']['policy_status']=='current'


def test_policy_intent_routing():
    assert classify_policy_intent('What is the current return policy?') == 'current'
    assert classify_policy_intent('What did the previous policy say?') == 'archived'
    assert classify_policy_intent('Compare old and current delivery fees') == 'compare'


def test_change_between_archived_and_current_is_comparison():
    question = 'How did the minimum order for free standard delivery change between the archived and current policies?'
    assert classify_policy_intent(question) == 'compare'
    assert policy_filter(question) is None


def test_other_comparison_phrasings_retrieve_both_versions():
    questions = [
        'What is the difference between the old and current return window?',
        'Compare archived/current delivery fees.',
        'How has the delivery threshold changed from previous to current?',
    ]
    for question in questions:
        assert classify_policy_intent(question) == 'compare'
        assert policy_filter(question) is None


def test_current_filter_excludes_archived():
    assert policy_filter('What is the current return policy?') == {
        '$or': [{'policy_status':'current'}, {'policy_status':'not_applicable'}]
    }


def test_archived_filter_selects_archived_and_general_docs():
    assert policy_filter('What did the previous policy say about returns?') == {
        '$or': [{'policy_status':'archived'}, {'policy_status':'not_applicable'}]
    }


def test_citation_extraction_and_source_matching():
    answer = 'The return period is 14 days [03_current_customer_policy.md].'
    cited = extract_cited_sources(answer)
    assert cited == ['03_current_customer_policy.md']
    assert citation_source_match(cited, ['03_current_customer_policy.md']) == 'MATCHED'
    assert citation_source_match(cited, ['04_archived_customer_policy.md']) == 'UNMATCHED'
    assert citation_source_match(cited, ['03_CURRENT_CUSTOMER_POLICY.MD']) == 'MATCHED'
    assert citation_source_match([], ['03_current_customer_policy.md']) == 'MISSING'


def test_source_excerpt_is_short_and_unique_per_file():
    chunks = [
        SimpleNamespace(metadata={'source': 'a.md'}, text='A useful evidence sentence. ' * 40),
        SimpleNamespace(metadata={'source': 'a.md'}, text='A second chunk from the same document.'),
        SimpleNamespace(metadata={'source': 'b.md'}, text='A different evidence sentence.'),
    ]
    excerpts = make_source_excerpts(chunks, max_chars=70)
    assert [item['source'] for item in excerpts] == ['a.md', 'b.md']
    assert len(excerpts[0]['excerpt']) <= 70
