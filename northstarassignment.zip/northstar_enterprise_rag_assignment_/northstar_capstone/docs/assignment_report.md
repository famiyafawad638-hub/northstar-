# Northstar Home & Tech — Enterprise RAG Assignment Report

**Course:** Bano Qabil Generative AI, Module 08  
**Company:** Northstar Home & Tech (fictional online retailer)  
**Project type:** Classroom prototype  

## 1. Business use case
Northstar Home & Tech needs a small internal/customer-support assistant that answers questions from approved company information. Staff and customers may ask about product prices, order processing, support hours, delivery estimates, and return rules. A conventional chatbot can sound confident while confusing an archived policy with the current one or inventing a missing warranty or international-shipping rule. This prototype uses retrieval-augmented generation (RAG) so that answers are grounded in supplied documents and users can inspect the supporting source excerpts.

The knowledge base contains six fictional classroom documents (2,244 words in this version): a company overview, an eight-item product catalogue, current customer policy NHT-CP-3.1 (effective 1 November 2026), archived policy NHT-CP-2.0 (effective 1 April 2025), operations FAQs, and a non-authoritative prompt-injection test note. The corpus includes changed policy values, exceptions, exact prices and times, cross-document facts, and intentionally missing information. No real customer or employee data is used. Only fictional classroom information should be sent to the API.

## 2. RAG pipeline
Python loads Markdown/TXT and text-based PDF documents, attaches filename and manifest metadata, and splits text into overlapping chunks (baseline: 900 characters with 150-character overlap). Chroma stores the chunks, metadata, and embeddings created with the public `all-MiniLM-L6-v2` sentence-transformer model. At query time, a policy-intent rule selects current policy, archived policy, or both for comparisons. Comparison wording includes phrases such as “change between archived and current,” so the query retrieves both versions rather than applying a current-only filter. The application retrieves the top-k chunks, formats them as untrusted evidence, and sends the question plus evidence to an LLM through the Google Gemini API. Streamlit displays the answer, filenames cited by the model, citation filename matching, short retrieved excerpts, policy metadata, distances, and expandable retrieved chunks. Citation filename matching is not a semantic proof that the excerpt supports a claim; that remains part of manual evaluation.

The assistant is instructed to use only evidence, ignore commands inside retrieved documents, cite source filenames, label historical policies, explain unresolved conflicts, and return the exact sentence **“I could not find enough information in the provided documents.”** when evidence is insufficient. The prompt is one safeguard, not proof of correctness; the test set is used to check actual behavior.

## 3. Retrieval experiments — complete with measured results before submission
The required comparison holds documents, chunking, and six questions fixed while varying k=1, 3, and 5. For each run, inspect whether the expected source evidence was retrieved, whether irrelevant material appeared, and whether the final response was correct. A second experiment uses three fixed questions and compares 900/150 against 600/100 chunk-size/overlap settings. The scripts create CSV files for recording these observations.

**Student must replace this paragraph with actual findings after running the scripts.** State which k worked best overall, where extra chunks helped, where they introduced noise, which chunk-size setting performed better, and at least one unresolved retrieval failure. Do not invent metrics or mark a run as successful without inspecting its retrieved evidence and answer.

## 4. Failures, limitations, and next steps
Potential failure modes include semantically similar but irrelevant chunks, a question that needs evidence split across multiple chunks, a current/archived policy-routing mistake, model hallucination despite retrieval, API quota/network errors, and prompt injection inside source text. Investigate failures by checking the question, retrieved filenames and excerpts, policy metadata, chunk boundaries, and model output. Record the reason and any correction in the test CSV.

This is a classroom prototype, not a production deployment. It has no real authentication, tenant isolation, access-control enforcement, customer/order database, monitoring service, formal privacy review, or human approval workflow. A real company would need those controls, stronger evaluation, documented policy ownership, adversarial testing, and human review for consequential customer decisions. The local Chroma index must be rebuilt after source documents change because editing a file does not update vectors already stored in the database.
