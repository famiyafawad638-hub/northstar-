# Beginner Guide — Do This in Order

This project is intended to be run on a Windows, macOS, or Linux computer. A phone is useful for reading the guide, but a laptop/desktop is much easier for installing Python, editing files, and recording the demo. If you do not have a computer, ask your instructor whether you can use the lab.

## Step 1 — Download and extract
Download `northstar_enterprise_rag_assignment.zip` and extract it. Open the extracted `northstar_capstone` folder. Do not rename individual knowledge documents because the manifest and test CSV refer to their filenames.

## Step 2 — Install Python
Install Python 3.11 or another supported Python 3.10+ version. During Windows installation, select the option to add Python to PATH if it is offered. Open PowerShell or Terminal and run `python --version` (on some Windows systems, use `py --version`).

## Step 3 — Open a terminal in the project folder
In Windows File Explorer, open the project folder, click the address bar, type `powershell`, and press Enter. On macOS/Linux, open Terminal and use `cd` to enter the extracted project folder. The prompt should now show that folder.

## Step 4 — Create a separate Python environment
A virtual environment keeps this project's packages separate from other Python projects.

Windows PowerShell:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

If PowerShell blocks activation, do not change system security settings blindly; ask your instructor to help or use the documented Python command prompt approach.

## Step 5 — Install the project packages

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

The first install needs internet. The first application run also downloads the public sentence-transformer embedding model. The model cache stays on your computer and is not part of the ZIP.

## Step 6 — Configure the LLM key safely
Copy `.env.example` to a new file named `.env`. Open `.env` in a text editor and put the API key into `GEMINI_API_KEY`. Keep the key private. Do not put it in `rag.py`, `app.py`, the README, a screenshot, a public repository, or the LMS ZIP. The `.env` file is ignored by Git and excluded from the ZIP. Use the API only under the provider's current age, school, and account rules; ask your instructor or parent/guardian to help with account setup where required. The free tier may have quota limits and its data terms can differ from paid service. This project uses fictional information only.

## Step 7 — Build the vector database

```bash
python rebuild_index.py
```

This reads the knowledge documents, splits them into chunks, creates embeddings, and stores the chunks plus metadata in Chroma. It prints the number of indexed chunks. If something fails, copy the full error message and ask your instructor for help rather than deleting files at random.

## Step 8 — Start the website

```bash
streamlit run app.py
```

Open the local web address shown in the terminal, usually `http://localhost:8501`. Ask a question such as `What is the current return period for an unopened product?` Expand the retrieved evidence and confirm the source filename and policy version. Try a second question that needs two documents.

## Step 9 — Run all 20 tests

```bash
python run_test_set.py
```

Open `results/test_set_and_results.csv`. It contains the expected answer and expected source for each question before the actual run. The script adds the actual answer and retrieved filenames. Read each row and change `REVIEW` to `PASS` or `FAIL`; write a reason for each failure. A script cannot responsibly decide whether an explanation is factually correct merely by matching a few words.

## Step 10 — Run the retrieval experiments

```bash
python run_retrieval_experiments.py --with-answers
```

It compares six unchanged questions at k=1, 3, and 5, then three questions with two chunk settings. This makes 24 LLM calls. Check the generated answers and the actual chunk excerpts. Complete all fields marked `NOT_REVIEWED`. Explain whether extra chunks improved evidence coverage or introduced irrelevant content. Keep the six questions and source documents unchanged for the k comparison.

## Step 11 — Finish the report and demo
Open `docs/assignment_report.md`. Replace the instruction asking for actual experiment findings with the results you observed; do not invent numbers or claim success where a test failed. Record the six demo actions listed in the README in a 3–5 minute video, upload it to a location your instructor accepts, and paste your actual share link into README.

## Step 12 — Make the final ZIP
Do not include `.env`, `.venv`, `chroma_db`, Python caches, downloaded embedding models, or personal data. The prepared project ZIP is under 5 MB. After running experiments, add your completed CSV results and updated report to the final ZIP. Keep the original source documents if you want repeatable tests.

## What the main Python files do
- `src/documents.py`: reads documents and creates chunks while attaching filename/version/status metadata.
- `src/rag.py`: builds/queries Chroma, selects policy versions, calls Gemini, and formats evidence.
- `app.py`: presents the Streamlit user interface.
- `rebuild_index.py`: rebuilds vectors after source documents change.
- `run_test_set.py`: asks the 20 fixed test questions and records actual outputs.
- `run_retrieval_experiments.py`: compares k values and chunk sizes and records retrieval/answer evidence for manual review.

You should be able to explain what each file does before the demonstration. The assignment explicitly allows AI assistance but expects each student to understand and explain the submitted code.
