# Northstar Home & Tech — Products and Services Catalogue
Document type: product catalogue | Version: 2026.11 | Price list effective: 10 November 2026 | Status: CURRENT

All prices are fictional Pakistani rupee (PKR) examples, not real offers. The Product team changes a price only by publishing a new dated catalogue.

## Eight catalogue offerings
1. **Northstar AirLite Wireless Earbuds — PKR 6,500.** Wireless earbuds for calls and everyday listening. The box contains a charging case, USB-C cable, and quick-start card. Battery life depends on usage; no guaranteed duration is stated.
2. **Northstar QuietType Keyboard — PKR 4,200.** Wired full-size keyboard with number pad and adjustable feet. The standard item is not personalized. A classroom demonstration option allows name engraving. Personalized items are not returnable for change of mind; report a verified manufacturing defect within 7 calendar days after delivery for review.
3. **Northstar FoldStand Laptop Stand — PKR 2,800.** Foldable aluminium stand. Laptop is not included; customers should check supported dimensions before ordering.
4. **Northstar View27 Monitor — PKR 38,500.** 27-inch office monitor supplied with stand and power cable. Some demonstration units may be marked clearance; the label is shown beside the price before checkout.
5. **Northstar Connect USB-C Hub — PKR 3,500.** Multi-port adapter for compatible USB-C devices. Physical connector fit does not guarantee that every host device supports all data or display features.
6. **Northstar Focus Webcam — PKR 7,200.** Plug-and-play webcam with privacy cover and USB cable. Lighting, internet, and meeting software affect video quality.
7. **Northstar Glow Desk Lamp — PKR 2,500.** Adjustable desk lamp supplied with a power adapter; it is not a battery-powered emergency light.
8. **Northstar ErgoSeat Chair — PKR 32,000.** Adjustable office chair requiring assembly. An approved return pickup costs PKR 500 when the return is not caused by a verified defect. This is a special collection-charge exception; ordinary return conditions still apply.

## Services and policy boundaries
The store offers standard courier delivery, order-status support, and return-request guidance. Customers receive an order confirmation after payment and a dispatch notification after courier handover. A tracking link can take several hours to show its first scan. Support cannot promise an arrival time that the courier has not confirmed.

This catalogue answers product names, descriptions, and listed prices. Return eligibility, return periods, shipping charges, and delivery estimates come from the policy marked CURRENT. Clearance items are final sale for change-of-mind returns under the current policy, except that damage or a verified defect can still be reported. The current policy also controls the personalized-keyboard exception and the chair pickup charge described above.

The supplied documents do not state a universal manufacturer warranty period for every product, and they do not state the engraving fee for a personalized keyboard. Do not infer either amount or duration from another rule. The 7-day defect-reporting window for the personalized keyboard is not a general warranty promise.
