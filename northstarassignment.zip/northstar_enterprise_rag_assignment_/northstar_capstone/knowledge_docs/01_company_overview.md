# Northstar Home & Tech — Company Overview
Document type: company overview | Owner: Operations | Last reviewed: 10 November 2026

## About the company
Northstar Home & Tech is a fictional Pakistan-based online retailer created only for this classroom RAG assignment. It has no real customers, employees, warehouse, phone number, or payment account. All names, prices, processes, and policies are invented examples. The store serves students, remote workers, and small offices with computer peripherals, desk accessories, lighting, and ergonomic products. Customers can browse without an account; an account is required to view order history or submit a return request.

## Service area
Northstar accepts online orders at serviceable addresses in Pakistan. Standard delivery covers major cities and many smaller towns. Some remote mountain and rural routes take longer. The courier's postcode coverage is checked before checkout is accepted; an accepted order does not mean all destinations have the same delivery estimate.

The supplied documents do not confirm international shipping. Do not promise delivery to another country based on assumptions. For an international-shipping question, say that the supplied company documents do not establish availability or price and refer the customer to Support for a manual check.

## Departments
Customer Support answers product, order, delivery, and return questions. Fulfilment checks stock, packs paid orders, and hands parcels to the courier. Product maintains the catalogue and prices. The Operations Policy Owner approves policy changes and publishes dated replacements. Support can explain published rules but cannot invent an exception or change a policy. Unusual cases go to the Operations supervisor for review.

## Communication principles
Use plain language, cite the source of policy answers, and distinguish a confirmed rule from an estimate. Never ask a customer for a password, card number, or one-time code. If the documents do not answer a question, say so rather than guessing. If two applicable documents conflict and their dates/status do not resolve the conflict, explain the conflict and refer it to the Policy Owner.

The company overview describes the organization and service area. Questions about current return windows, shipping charges, and delivery estimates must use the document marked CURRENT. The archived policy is for explicit historical questions and comparisons only.
