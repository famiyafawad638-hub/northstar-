# Northstar Home & Tech — Previous Customer Policy (Archived)
Document type: customer policy | Policy version: NHT-CP-2.0 | Effective date: 1 April 2025 | Policy status: ARCHIVED
Replaced by NHT-CP-3.1, effective 1 November 2026

This document is retained for historical questions and comparisons only. It is not the current rule. All fees and dates are fictional classroom examples.

## 1. Former delivery terms
Under NHT-CP-2.0, standard delivery was free for a merchandise subtotal of **PKR 5,000 or more**. Below PKR 5,000, the fee was **PKR 200**. The former policy used one general estimate of **2–4 business days after dispatch** for serviceable addresses and did not state a separate 4–6 day estimate for remote destinations.

These terms were replaced on 1 November 2026. Do not present the PKR 5,000 threshold or PKR 200 fee as current. Identify them as former terms in archived policy NHT-CP-2.0, effective 1 April 2025.

## 2. Former return terms
An eligible, unopened standard product could be returned within **30 calendar days after delivery** if unused, complete, and in its original packaging. The customer submitted a request through the order page for review. This 30-day period is archived and must not be used when the customer asks for today's return window.

The former policy also required customers to report a damaged or incorrect order promptly. It did not create a general manufacturer-warranty promise. Historical answers should include the policy identifier and effective date so the old 30-day period is not confused with today's 14-day period.

## 3. Status and known changes
NHT-CP-2.0 is marked **ARCHIVED**. It remains available for audit, training, and explicit historical comparisons but does not override the current policy. The current version shortened the unopened-product return period from 30 to 14 calendar days, raised the free-delivery threshold from PKR 5,000 to PKR 8,000, and raised the below-threshold fee from PKR 200 to PKR 250. The current policy also gives remote destinations a separate 4–6 business day estimate. These changes are summarized here for comparison; the current policy controls today's customer questions.
