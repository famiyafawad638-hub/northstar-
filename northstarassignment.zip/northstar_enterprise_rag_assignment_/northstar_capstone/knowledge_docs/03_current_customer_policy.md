# Northstar Home & Tech — Current Customer Policy
Document type: customer policy | Policy version: NHT-CP-3.1 | Effective date: 1 November 2026 | Policy status: CURRENT
Approved by: Fictional Operations Policy Owner

This is the current classroom policy. Use it for present-day rules, not the archived version. All prices, dates, and terms are fictional examples.

## 1. Standard delivery
Standard delivery is free when the merchandise subtotal is **PKR 8,000 or more**. Below PKR 8,000, the standard delivery fee is **PKR 250**. The threshold is based on merchandise subtotal before separately displayed fees. Checkout shows the final delivery charge before payment.

After dispatch, the usual estimate is **2–4 business days** for major-city routes and **4–6 business days** for remote destinations, including some mountain and rural routes. These are estimates, not guarantees. Courier disruption, holidays, weather, or address correction can add time. The company overview states that delivery is accepted only for serviceable Pakistan addresses.

## 2. Returns
An eligible, unopened standard product may be returned within **14 calendar days after delivery** if unused, complete, and in its original packaging with included accessories. The customer submits a request through the order page; Support checks the order and condition before providing next steps.

An opened electronic product is not eligible for a change-of-mind return under the standard rule. If an opened electronic product is damaged or has a verified fault, contact Support within **7 calendar days after delivery** for review under the defect procedure. This reporting window is not a general warranty promise.

## 3. Exceptions
- **Clearance items:** An item visibly marked clearance before checkout is final sale for change-of-mind returns. Damage or a verified defect may still be reported and reviewed.
- **Personalized keyboards:** A QuietType keyboard with customer-requested engraving cannot be returned because the customer changes their mind. A verified manufacturing defect should be reported within 7 calendar days after delivery. The catalogue describes the personalization option; this policy determines the return decision.
- **Bulky chair pickup:** An approved ErgoSeat return pickup costs **PKR 500** when the return is not caused by a verified defect. Support reviews defective-chair cases before applying a collection charge.

## 4. Damaged, incorrect, and cancelled orders
Report visible transit damage or an incorrect item promptly, preferably with photographs. Support checks the order and may request more information. Do not promise a refund or replacement before review. A cancellation may be requested before courier handover; after dispatch, the normal return process applies. Cancellation is not confirmed until the order page or Support shows cancelled status. Payment-reversal timing is not specified here.

## 5. Version control
NHT-CP-3.1 became effective on **1 November 2026** and is marked **CURRENT**. It replaced NHT-CP-2.0. Use this version for current rules. If someone explicitly asks about the former rule, retrieve the archived policy and label it historical. For comparisons, state both versions and dates. If applicable current documents conflict without establishing which rule controls, explain the conflict instead of silently choosing one.
