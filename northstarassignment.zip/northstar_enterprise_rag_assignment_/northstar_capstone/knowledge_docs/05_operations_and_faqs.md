# Northstar Home & Tech — Operations and Frequently Asked Questions
Document type: operations guide and FAQ | Version: OPS-1.4 | Last reviewed: 10 November 2026 | Status: current operational guidance

## Order processing
Paid orders received **before 2:00 p.m. Pakistan Standard Time (PKT)** on a business day are normally queued for processing that business day. Orders received at or after 2:00 p.m. are normally queued on the next business day. This is a warehouse processing target, not a delivery promise. Stock checks, payment review, holidays, and address clarification can delay processing. Dispatch occurs only after Fulfilment hands the packed parcel to the courier.

Customers receive an order confirmation after payment and a separate dispatch notification after courier handover. A tracking page may take several hours to show its first scan. Support must distinguish processing, packed, and dispatched statuses.

## Support hours and escalation
Customer Support is available **Monday through Saturday, 9:00 a.m. to 6:00 p.m. PKT**. It is closed on Sunday and published company holidays. Messages received outside hours enter the next support queue. Customers can place website orders outside Support hours, but a staff response should not be promised until the team reopens.

Support explains published product and policy information. Disputed interpretations, damaged shipments, personalized products, and bulky-chair pickup cases may be escalated to the Operations supervisor. Only the Policy Owner can approve and publish a policy version. A one-off review does not automatically change the rule for everyone.

## FAQs
**Can a customer order at night?** Yes. Website ordering is available outside Support hours. A paid order received after the 2:00 p.m. cutoff is normally queued on the next business day.

**Does same-day processing mean same-day delivery?** No. Processing and delivery are separate stages. Delivery estimates begin after dispatch and are stated in the current policy. No same-day delivery guarantee is documented.

**What if tracking has no scan?** Allow several hours after dispatch for the first courier scan. If it remains unchanged beyond the next business day, contact Support with the order reference. Do not invent a courier status.

**Who handles an unusual case?** Support records the question and forwards it to the Operations supervisor, who consults the Policy Owner when needed.

## Questions requiring more than one document
To answer whether Northstar serves a remote town and how long delivery usually takes, combine this company's overview of serviceable Pakistan addresses with the current policy's 4–6 business day remote estimate. A question about an engraved keyboard should combine the catalogue description with the current policy's personalized-item exception.

## Information not specified
The supplied documents do not state a universal manufacturer warranty duration, an international shipping schedule or fee, or the engraving fee for a personalized keyboard. Do not invent these details. Use the exact insufficient-evidence response when the documents do not answer a question.
