from __future__ import annotations
import streamlit as st
from src.rag import ensure_index, answer_question

st.set_page_config(page_title="Northstar Knowledge Assistant", page_icon="📚", layout="wide")
st.title("📚 Northstar Home & Tech — Knowledge Assistant")
st.caption("A classroom prototype that answers from fictional company documents using retrieval-augmented generation (RAG).")

def load_index():
    return ensure_index()

with st.sidebar:
    st.header("About this assistant")
    st.write("Northstar is a fictional Pakistani online store. This demo uses only the supplied classroom knowledge documents.")
    k = st.slider("Number of retrieved chunks (k)", min_value=1, max_value=8, value=5)
    st.info("Current-policy questions exclude archived policy chunks. Historical questions retrieve archived policy. Comparison questions can retrieve both versions.")
    if st.button("Rebuild knowledge index", use_container_width=True):
        with st.spinner("Rebuilding Chroma index from knowledge_docs..."):
            try:
                from src.rag import build_index
                build_index(force=True)
                st.success("Index rebuilt from the supplied documents.")
            except Exception as exc:
                st.error(f"Index rebuild failed: {exc}")

try:
    collection = load_index()
    st.success(f"Knowledge base ready: {collection.count()} indexed chunks.")
except Exception as exc:
    st.error(f"Could not prepare the knowledge base: {exc}")
    st.info("Install requirements and check that knowledge_docs contains the supplied files. The embedding model downloads on first run.")
    st.stop()

question = st.text_area("Ask a question about Northstar", placeholder="Example: What is the current return period for an unopened product?", height=100)
if not question.strip():
    st.caption("Enter a question above, then select **Ask the assistant**.")
if st.button("Ask the assistant", type="primary", disabled=not question.strip()):
    with st.spinner("Retrieving evidence and generating an answer..."):
        result = answer_question(question, k=k, collection=collection)
    st.subheader("Answer")
    if result.get("error"):
        st.warning(result["answer"])
    else:
        st.markdown(result["answer"])

    cited_sources = result.get("cited_sources", [])
    citation_match = result.get("citation_source_match", "MISSING")
    st.subheader("Citations and supporting excerpts")
    if citation_match == "MATCHED":
        st.success("The cited filenames are present in the retrieved evidence. Please still check that each excerpt supports the claim.")
    elif citation_match == "UNMATCHED":
        st.warning("At least one filename cited by the model was not among the retrieved sources. Review this answer before relying on it.")
    else:
        st.warning("No bracketed source filename was detected in the answer. Review the evidence and do not mark this test PASS until citation requirements are met.")

    excerpts_by_source = {
        item.get("source", ""): item.get("excerpt", "")
        for item in result.get("source_excerpts", [])
    }
    if cited_sources:
        for source in cited_sources:
            st.markdown(f"**{source}**")
            excerpt = excerpts_by_source.get(source)
            if excerpt:
                st.caption(f"Retrieved excerpt: {excerpt}")
            else:
                st.caption("No retrieved excerpt from this cited file was found. Check the citation.")
    else:
        st.info("No source filename was cited in the generated answer. The retrieved chunks are shown below for inspection.")

    chunks = result.get("chunks", [])
    st.subheader("Retrieved evidence")
    if not chunks:
        st.info("No evidence chunks were retrieved for this question.")
    else:
        for idx, chunk in enumerate(chunks, start=1):
            meta = chunk.metadata
            label = f"{idx}. {meta.get('source','unknown')} | {meta.get('policy_version','n/a')} | {meta.get('policy_status','n/a')} | distance {chunk.distance:.3f}"
            with st.expander(label):
                st.caption(f"Effective date: {meta.get('effective_date','unknown')} · Chunk: {meta.get('chunk_index','?')}")
                st.write(chunk.text)
    if result.get("error"):
        st.caption("API errors are shown above; retrieved evidence remains visible so the issue can be investigated.")

st.divider()
st.caption("Prototype limitations: fictional data, no customer accounts, no order-system integration, no payment processing, no legal guarantee, and no production access controls. Verify answers before using any real business information.")
