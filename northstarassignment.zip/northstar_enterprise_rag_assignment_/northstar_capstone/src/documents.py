"""Load and chunk the supplied classroom knowledge documents."""
from __future__ import annotations
from pathlib import Path
import hashlib, json
from typing import Iterable

ROOT = Path(__file__).resolve().parents[1]
DOCS_DIR = ROOT / "knowledge_docs"
MANIFEST_PATH = DOCS_DIR / "manifest.json"


def load_documents(docs_dir: Path = DOCS_DIR) -> list[dict]:
    """Load Markdown/TXT and text-based PDF files with manifest metadata."""
    manifest_path = docs_dir / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
    items: list[dict] = []
    for path in sorted(docs_dir.iterdir()):
        if path.name == "manifest.json" or path.is_dir():
            continue
        suffix = path.suffix.lower()
        if suffix in {".md", ".txt"}:
            text = path.read_text(encoding="utf-8", errors="replace")
        elif suffix == ".pdf":
            try:
                from pypdf import PdfReader
                reader = PdfReader(str(path))
                text = "\n".join(page.extract_text() or "" for page in reader.pages)
            except Exception as exc:
                raise RuntimeError(f"Could not read text-based PDF {path.name}: {exc}") from exc
            if not text.strip():
                raise ValueError(f"{path.name} has no extractable text. Scanned PDFs/OCR are outside this assignment.")
        else:
            continue
        if not text.strip():
            continue
        metadata = manifest.get(path.name, {})
        items.append({"source": path.name, "text": text, "metadata": metadata})
    if not items:
        raise ValueError(f"No readable .md, .txt, or text-based .pdf files found in {docs_dir}")
    return items


def chunk_text(text: str, chunk_size: int = 900, overlap: int = 150) -> list[str]:
    """Create overlapping character chunks, preferring word boundaries."""
    if chunk_size < 200:
        raise ValueError("chunk_size must be at least 200 characters")
    if overlap < 0 or overlap >= chunk_size:
        raise ValueError("overlap must be >= 0 and smaller than chunk_size")
    text = " ".join(text.split())
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + chunk_size, len(text))
        if end < len(text):
            boundary = text.rfind(" ", start + int(chunk_size * 0.75), end)
            if boundary > start:
                end = boundary
        piece = text[start:end].strip()
        if piece:
            chunks.append(piece)
        if end >= len(text):
            break
        start = max(end - overlap, start + 1)
    return chunks


def make_records(items: list[dict], chunk_size: int = 900, overlap: int = 150) -> list[dict]:
    records: list[dict] = []
    for item in items:
        pieces = chunk_text(item["text"], chunk_size, overlap)
        meta_base = {
            "source": item["source"],
            "doc_type": str(item["metadata"].get("doc_type", "general")),
            "policy_version": str(item["metadata"].get("policy_version", "not_applicable")),
            "policy_status": str(item["metadata"].get("policy_status", "not_applicable")),
            "effective_date": str(item["metadata"].get("effective_date", "unknown")),
        }
        for idx, piece in enumerate(pieces):
            identity = f"{item['source']}|{idx}|{piece}".encode("utf-8")
            records.append({"id": hashlib.sha256(identity).hexdigest(), "text": piece,
                            "metadata": {**meta_base, "chunk_index": idx}})
    return records


def source_fingerprint(items: list[dict], chunk_size: int, overlap: int) -> str:
    digest = hashlib.sha256(f"{chunk_size}:{overlap}".encode())
    for item in items:
        digest.update(item["source"].encode())
        digest.update(item["text"].encode())
        digest.update(json.dumps(item["metadata"], sort_keys=True).encode())
    return digest.hexdigest()
