"""Small helpers for reporting citations and retrieved source excerpts."""
from __future__ import annotations

import re
from pathlib import Path
from textwrap import shorten
from typing import Iterable

_CITATION_PATTERN = re.compile(r"\[\s*([^\[\]]+?\.(?:md|txt|pdf))\s*\]", re.IGNORECASE)


def extract_cited_sources(answer: str) -> list[str]:
    """Extract bracketed document filenames from the generated answer."""
    found: list[str] = []
    for match in _CITATION_PATTERN.findall(answer or ""):
        filename = Path(match.strip()).name
        if filename and filename not in found:
            found.append(filename)
    return found


def citation_source_match(cited_sources: Iterable[str], retrieved_sources: Iterable[str]) -> str:
    """Check whether cited filenames occur among retrieved filenames.

    This is a source-presence check, not proof that an excerpt logically
    supports every claim. A human still has to inspect the evidence.
    """
    cited = {str(name).casefold() for name in cited_sources if str(name).strip()}
    retrieved = {str(name).casefold() for name in retrieved_sources if str(name).strip()}
    if not cited:
        return "MISSING"
    return "MATCHED" if cited.issubset(retrieved) else "UNMATCHED"


def make_source_excerpts(chunks, max_chars: int = 360) -> list[dict[str, str]]:
    """Return one short, high-ranked retrieved excerpt for each source file."""
    excerpts: list[dict[str, str]] = []
    seen: set[str] = set()
    for chunk in chunks:
        source = str(chunk.metadata.get("source", "unknown"))
        if source in seen:
            continue
        seen.add(source)
        excerpt = shorten(" ".join(chunk.text.split()), width=max_chars, placeholder="…")
        excerpts.append({"source": source, "excerpt": excerpt})
    return excerpts
