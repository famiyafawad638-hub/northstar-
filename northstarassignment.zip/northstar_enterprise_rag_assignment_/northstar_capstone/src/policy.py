"""Policy-intent classification and Chroma metadata filters.

Kept separate from the provider/database code so the routing rules can be
unit-tested without installing Chroma, sentence-transformers, or an LLM SDK.
"""
from __future__ import annotations

import re
from typing import Optional


_COMPARE_PATTERNS = (
    r"\bcompare\b",
    r"\bcomparison\b",
    r"\bdifference(?:s)?\b",
    r"\bversus\b",
    r"\bvs\.?\b",
    r"\bchanged?\b",
    r"\bchange\s+(?:from|between|in)\b",
    r"\bbetween\s+(?:the\s+)?(?:old|previous|archived|former)\s+(?:and|/)\s+(?:the\s+)?(?:current|new|today(?:'s)?)\b",
    r"\b(?:old|previous|archived|former)\s*(?:/|and)\s*(?:current|new)\b",
    r"\b(?:previous|old|archived)\s+policy\s+to\s+(?:the\s+)?current\b",
)
_ARCHIVE_PATTERNS = (
    r"\bprevious\b",
    r"\bformer\b",
    r"\bold\s+policy\b",
    r"\barchived\b",
    r"\bhistorical\b",
    r"\bbefore\s+november\b",
    r"\bbefore\s+1\s+november\b",
)


def classify_policy_intent(question: str) -> str:
    """Return ``compare``, ``archived`` or ``current``.

    Comparison is checked before historical wording because a comparison
    question usually mentions both versions and must retrieve both.
    """
    q = (question or "").lower()
    if any(re.search(pattern, q) for pattern in _COMPARE_PATTERNS):
        return "compare"
    if any(re.search(pattern, q) for pattern in _ARCHIVE_PATTERNS):
        return "archived"
    return "current"


def policy_filter(question: str) -> Optional[dict]:
    """Return a Chroma ``where`` filter; ``None`` means both policy versions."""
    mode = classify_policy_intent(question)
    if mode == "compare":
        return None
    if mode == "archived":
        return {"$or": [
            {"policy_status": "archived"},
            {"policy_status": "not_applicable"},
        ]}
    return {"$or": [
        {"policy_status": "current"},
        {"policy_status": "not_applicable"},
    ]}
