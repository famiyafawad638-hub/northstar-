"""Rebuild the persistent Chroma database from knowledge_docs."""
from src.rag import build_index

if __name__ == "__main__":
    collection = build_index(force=True)
    print(f"Index rebuilt successfully: {collection.count()} chunks.")
