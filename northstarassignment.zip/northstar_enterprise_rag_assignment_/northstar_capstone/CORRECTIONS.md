# Northstar RAG ZIP — correction notes

This ZIP is a corrected version of the uploaded Northstar assignment package.

## Code fixes

1. **Old/current policy comparison routing**
   - Added comparison patterns for phrases such as `change between`, `between archived and current`, `old/current`, and `previous/current`.
   - Comparison requests return no policy-status filter, allowing both archived and current policy chunks to be retrieved.
   - Added a regression test using the exact wording of assignment test T14.

2. **Citation tracking in test results**
   - Kept `actual_source_documents` for documents retrieved by Chroma.
   - Added `actual_cited_sources` for bracketed filenames that actually appear in the model's answer.
   - Added `citation_source_match` with `MATCHED`, `UNMATCHED`, or `MISSING` values.
   - Added `actual_supporting_excerpts` and `run_error` columns to the 20-question test CSV.
   - The experiment outputs now also preserve cited filenames and excerpts when `--with-answers` is used.

3. **Streamlit citation display**
   - The app displays the filenames cited in the answer, a warning if citations are missing or unmatched, and a short retrieved excerpt for inspection.
   - Full retrieved chunks remain expandable.
   - A matching filename is only a source-presence check; students must still verify that the excerpt supports the claim.

4. **Gemini temporary-error handling**
   - The Gemini client explicitly configures up to five total request attempts with exponential backoff for transient HTTP codes (408, 429, 500, 502, 503, 504).
   - If the provider is still unavailable, the app shows a readable message and keeps retrieved evidence visible.
   - The model default remains `gemini-3.8-flash`; confirm account availability and quotas before running.

5. **Testability and dependencies**
   - Policy rules and citation helpers are separated into lightweight modules so unit tests do not require Chroma or an LLM API.
   - The `google-genai` minimum version is 1.49 to support configured retry options.

## Checks performed in this environment

- Python compile check: passed.
- Core unit tests: 10 passed.
- Policy routing for T14: classified as `compare`; Chroma filter is `None` (both policy versions can be retrieved).
- Test dataset: 20 rows with required category split of 5 / 4 / 3 / 3 / 3 / 2.
- Knowledge document word count: 2,244, within the assignment's 1,500–2,500 range.

## Still must be done by the student

- Install `requirements.txt` in your own environment.
- Configure your own permitted Gemini API key in a local `.env` file (never include `.env` in the LMS ZIP).
- Build Chroma and run the Streamlit app.
- Run all 20 LLM-backed tests and manually mark each `PASS` or `FAIL` after checking answer accuracy and excerpt support.
- Run and manually review the k=1/3/5 and chunk-size experiments.
- Replace report placeholders with observed results and record the 3–5 minute demo.

No live Gemini request, Chroma database build, or demo recording was performed as part of this ZIP correction.
